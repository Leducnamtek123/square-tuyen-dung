# Hướng dẫn cấu trúc bộ ảnh nhân vật AI phỏng vấn

Bộ ảnh nhân vật AI chuẩn hóa giúp hệ thống kích hoạt đầy đủ biểu cảm cử động nhép môi và trạng thái tương tác với ứng viên trong phòng phỏng vấn.

## 1. Yêu cầu kỹ thuật tệp ảnh
- Định dạng: WebP khuyến nghị hoặc PNG tách nền trong suốt
- Tỷ lệ khung hình: 1:1 hoặc 3:4
- Độ phân giải khuyến nghị: 1024x1024 pixel
- Kích thước tệp: Dưới 300KB mỗi tệp để tối ưu tốc độ tải

## 2. Danh sách các tệp trạng thái bắt buộc
1. idle.webp: Trạng thái chờ sẵn sàng
2. listening.webp: Trạng thái lắng nghe ứng viên trả lời
3. thinking.webp: Trạng thái AI phân tích dữ liệu câu trả lời
4. processing.webp: Trạng thái xử lý kết quả đánh giá
5. blink.webp: Cử động chớp mắt tự nhiên chống đơ khung hình
6. speaking_01.webp đến speaking_08.webp: 8 khung hình chu kỳ nhép môi khi AI phát âm

## 3. Các tệp phản xạ cảm xúc mở rộng
7. agree.webp: Gật đầu đồng thuận
8. encouraging.webp: Mỉm cười khích lệ ứng viên
9. serious.webp: Đánh giá kỹ thuật chuyên sâu
10. happy.webp: Chào đón vui vẻ
11. curious.webp: Chăm chú tò mò
12. impressed.webp: Ấn tượng với câu trả lời hay
13. goodbye.webp: Kết thúc buổi phỏng vấn
